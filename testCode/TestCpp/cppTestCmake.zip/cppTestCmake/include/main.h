#ifndef _MAIN_H_
#define _MAIN_H_

#include "common.h"
#include "essentialPack.h"
#include "algorithmPack.h"
#include "classPack.h"

#endif
/* End of this file. */
