#ifndef _COMMON_H_
#define _COMMON_H_

#include <iostream>
//#include <cstdio>

#endif
/* End of this file. */