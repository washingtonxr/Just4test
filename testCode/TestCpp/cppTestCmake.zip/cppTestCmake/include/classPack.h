#ifndef _CLASSPACK_H_
#define _CLASSPACK_H_

int testClass(void);
int testClass2(void);
int privateClass(void);
int protectClass(void);
int publicInheritance(void);

#endif
/* End of this file. */